package Chapter01;

public class Test01 {
    public static void main(String[] args) {
        System.out.println("路漫漫其修远兮，吾将上下而求索");
    }
}