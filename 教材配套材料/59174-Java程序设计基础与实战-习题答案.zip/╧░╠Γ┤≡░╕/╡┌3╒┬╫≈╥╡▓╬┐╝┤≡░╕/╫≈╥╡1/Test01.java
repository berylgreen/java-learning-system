package Chapter03;

public class Test01 { // 创建书类
    public static void main(String[] args) {
        Test01 book = new Test01(); // 创建书类对象
        int shelf = 30; // 初始化书架上书的本数（实参）
        int box = 40; // 初始化箱子里书的本数（实参）
        // 把书架上的书全部放进箱子后，输出箱子里书的总数
        System.out.println("把书架上的书全部放进箱子后，箱子里一共有"
            + book.add(shelf, box) + "本书。\n明细如下：书架上"
            + shelf + "本书，箱子里原有" + box + "本书。");
    }
    private int add(int shelf, int box) { // 把书架上、箱子里的书相加求和（形参）
        box = box + shelf; // 对box进行加shelf操作
        return box; // 返回box
    }
}