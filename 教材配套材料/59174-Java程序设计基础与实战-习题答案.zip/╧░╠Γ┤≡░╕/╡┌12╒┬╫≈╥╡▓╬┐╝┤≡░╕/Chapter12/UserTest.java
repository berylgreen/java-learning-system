package Chapter12;

import java.util.ArrayList;
import java.util.Date;

public class UserTest {

    private static UserCRUD uc = new UserCRUD();

    public static void main(String[] args) {
        insertTest();
//        findAllUsersTest();
//        findUserByIdTest();
//        updateUserTest();
//        deleteUserTest();

    }

    public static void insertTest() {
        // 向users表插入一个用户信息
        User user = new User();

        user.setUsername("hahahah");
        user.setPassword("123");
        user.setEmail("hahahah@sina.com");
        user.setBirthday(new Date());
        boolean b = uc.insert(user);
        System.out.println(b);
    }

    public static void findAllUsersTest() {

        // 将UsersDao对象的findAll()方法执行后的结果放入list集合
        ArrayList<User> list = uc.findAll();
        // 循环输出集合中的数据
        for (int i = 0; i < list.size(); i++) {
            System.out.println("第" + (i + 1) + "条数据的username值为:" + list.get(i).getUsername());
        }
    }

    public static void findUserByIdTest() {
        User user = uc.find(1);
        System.out.println("id为1的User对象的name值为：" + user.getUsername());
    }

    public static void updateUserTest() {
        User user = new User();
        user.setId(4);
        user.setUsername("zhaoxiaoliu");
        user.setPassword("456");
        user.setEmail("zhaoxiaoliu@sina.com");
        user.setBirthday(new Date());
        boolean b = uc.update(user);
        System.out.println(b);
    }

    public static void deleteUserTest() {
        boolean b = uc.delete(4);
        System.out.println(b);
    }




}