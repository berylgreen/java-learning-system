package Chapter06;

//自定义异常，继承Exception类
public class InvalidRadiusException extends Exception {
	public InvalidRadiusException() {
		super();
	}

	public InvalidRadiusException(String message) {
		super(message);
	}
}