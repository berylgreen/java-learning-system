package Chapter07;


import java.util.ArrayList;
import java.util.Collections;

public class Test01 {
    public static void main(String[] args) {
        System.out.print("正序打印:"+" ");
        for (char i = 'A'; i <= 'Z'; i++) {
            char letters1 = i;
            System.out.print(letters1 + " ");
        }
        System.out.println();
        System.out.print("逆序打印:"+" ");
        for (char i = 'Z'; i >= 'A'; i--) {
            char letters2 = i;
            System.out.print(letters2 + " ");
        }
    }
}