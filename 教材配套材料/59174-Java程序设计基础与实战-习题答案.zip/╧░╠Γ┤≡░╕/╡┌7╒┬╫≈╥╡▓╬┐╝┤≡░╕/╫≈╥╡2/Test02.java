package Chapter07;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
public class Test02 {
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        /**
         * 利用HashMap创建一个城市有区号和城市名两列
         * */
        HashMap<String, String> cities = new HashMap<String, String>();
        cities.put("陕西", "线");
        cities.put("甘肃", "兰州");
        cities.put("青海", "西宁");
        cities.put("宁夏回族自治区", "银川");
        cities.put("新疆维吾尔族自治区", "乌鲁木齐");
        /**
         * 创建Set，是Key的集合,用来存放cities中所有的区号
         * */
        Set<String> code = cities.keySet();
        /**
         * 遍历存储在code中的所有cities的区号,打印出所有的区号
         * */
        Iterator<String> it = code.iterator();

        while(it.hasNext()){
            System.out.println("=======================");
            //得到所有的区号存放在zip中
            String zip=it.next();
            //根据区号的到区号对应的城市
            String cityName=cities.get(zip);
            System.out.println(zip+":"+cityName);
        }
    }
}