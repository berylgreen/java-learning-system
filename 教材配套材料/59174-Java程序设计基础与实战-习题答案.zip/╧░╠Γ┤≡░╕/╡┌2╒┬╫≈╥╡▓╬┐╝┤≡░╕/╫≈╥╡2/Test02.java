package Chapter02;

//统计字符数组中每个字符出现的个数
public class Test02 {
    public static void main(String[] args) {
        char [] arrs = {'a','b','b','b','a','c','a'};   //初始化需要统计字符的数组
        char [] arrs1 = new char[arrs.length];
        int [] num = new int [arrs.length];
        int count = 0;//记录字符的种类数据
        for (int i = 0; i < arrs.length; i++) {
            //1. 取到arrs中的一个字符(从数组中取出来的一个字符)
            char c = arrs[i];
            //2. 去arrs1中进行判断，是否存在的判断
            int index = -1;
            for (int j = 0; j < count; j++) {
                //如果进入到if说明找到相同的了，说明之前添加过该字符
                if (c==arrs1[j]){
                    index = j;
                }
            }
            //3. 根据index的值判断之前是否出现过该字符(c)
            if (index==-1){
                //说明该字符就是第一次出现
                arrs1[count]=c;
                num[count]=1;
                count++;
            }else {
                //说明该字符不是第一次出现
                num[index]=num[index]+1;
            }
        }
        //查看结果
        for (int i = 0; i < count; i++) {
            System.out.println(arrs1[i]+"------->"+num[i]);
        }
    }
}