package Chapter02;

public class Test01 {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            //每⼀列打印的星星个数跟⾏数相同，所以在下⾯for循环中将条件中最⼤值设置为⾏数
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}