package Chapter04;

class Vehicle //创建一个Vehicle类
{

    public void move() //创建一个普通的Move()方法
    {
        System.out.println("交通工具都可以移动"); //输出结果
    }
}

class Train extends Vehicle //创建一个Train类继承Vehicle
{

    @Override
    public void move() //重写Move()方法
    {
        System.out.println("火车在铁轨上行驶"); //输出结果
    }
}
class Car extends Vehicle //创建一个Car类继承Vehicle
{
    @Override
    public void move() //重写Move()方法
    {
        System.out.println("汽车在公路上行驶"); //输出结果
    }
}
public class Test02 {
    public static void main(String[] args) {
        Vehicle vehicle[] = {new Vehicle(), new Train(), new Car()}; //创建Vehicle（父类）类型的数组
        for (int i = 0; i < vehicle.length; i++) //遍历数组
        {
            vehicle[i].move(); //Vehicle（父类）类型的变量调用相应的Move()方法
        }
    }
}