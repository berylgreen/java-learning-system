package Chapter04;

public class Market {
    public static String pay(String payStyle) {
        return "所有的超市都支持" + payStyle;
    }

    public static String pay(String marketStyle, String payStyle) {
        return marketStyle + "还支持" + payStyle;
    }

    public static void main(String[] args) {
        System.out.println(pay("现金付款"));
        System.out.println("但" + pay("大型商超", "刷卡付款"));
    }
}