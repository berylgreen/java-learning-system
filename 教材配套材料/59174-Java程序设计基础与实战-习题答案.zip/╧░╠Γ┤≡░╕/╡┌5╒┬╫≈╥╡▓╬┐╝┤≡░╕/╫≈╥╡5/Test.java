package Chapter05;

public class Test {
	public static void say(Geometric o) {
		if (null == o)
			return;
		System.out.println(o);
		System.out.println("面积：" + o.getArea());
		System.out.println("周长：" + o.getPerimeter());
		System.out.println("颜色：" + o.getColor());
		System.out.println("填充：" + o.isFilled());
	}
	public static void main(String[] args) {
		say(new Circle(10));
		say(new Rectangle(10, 10));
		say(new Triangle(3, 4, 5));
	}
}