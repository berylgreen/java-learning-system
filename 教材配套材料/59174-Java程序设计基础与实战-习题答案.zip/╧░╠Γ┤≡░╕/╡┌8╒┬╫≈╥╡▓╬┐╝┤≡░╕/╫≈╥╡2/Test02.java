package Chapter08;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test02{

    public static void main(String[] args) throws IOException {
        FileReader b = new FileReader("D:\\test.txt");

        int i = 0;

        char[] p = new char[1024];

        while((i = b.read(p)) != -1){

            System.out.println(new String(p,0,i));

        }
        b.close();
    }
    }