package Chapter08;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test01 {

    public static void main(String[] args) throws IOException {
        FileWriter a = new FileWriter("D:\\test.txt");

        a.write("我写的代码没bug");
        a.flush();
        a.close();


    }
}