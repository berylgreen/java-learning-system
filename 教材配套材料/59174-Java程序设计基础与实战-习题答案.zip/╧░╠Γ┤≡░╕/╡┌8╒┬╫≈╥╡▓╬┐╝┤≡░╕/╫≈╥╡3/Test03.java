package Chapter08;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Test03 {

    public static void main(String[] args) throws IOException {
        FileInputStream fis = null;
        FileOutputStream fos = null;
        InputStreamReader ir = null;
        OutputStreamWriter or = null;

        File file = new File("D:\\test.txt");
        fis = new FileInputStream(file);
        fos = new FileOutputStream("D:\\my.txt");
        ir = new InputStreamReader(fis);
        or = new OutputStreamWriter(fos);
        int len = 0;
        char[] chars = new char[1024];
        while ((len = ir.read(chars)) != -1) {
            String s = new String(chars, 0, len);
            or.write(s, 0, len);
            or.flush();
        }
        System.out.println("success");

        ir.close();
        or.close();


    }

}