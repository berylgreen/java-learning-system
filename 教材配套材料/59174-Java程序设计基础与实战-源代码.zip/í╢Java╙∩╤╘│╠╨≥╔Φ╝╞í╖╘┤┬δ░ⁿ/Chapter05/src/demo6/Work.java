package demo6;

public interface Work {
  public void work();
}