/*
package demo2;
abstract class Parent {
  public abstract void say();
  public abstract void work();
}
// 继承抽象方法
class Child extends Parent {
  // 实现抽象方法
  public void say() {
    System.out.println("Child");
  }

*/
/*  @Override
  public void work() {

  }*//*

}
public class TestAbstractMeth {
  public static void main(String[] args) {
    Child c = new Child();
    c.say();
  }
}*/