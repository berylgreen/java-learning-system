package demo15;

public interface ServiceOne {

  //	定义一个printMessage方法
  void printMessage(String message);
}