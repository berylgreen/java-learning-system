package demo5;
//问候接口
public interface Talk {
  public void talk();
}