package test1;

public interface USB {
  void turnOn();//启动
  void turnOff();//关闭
}