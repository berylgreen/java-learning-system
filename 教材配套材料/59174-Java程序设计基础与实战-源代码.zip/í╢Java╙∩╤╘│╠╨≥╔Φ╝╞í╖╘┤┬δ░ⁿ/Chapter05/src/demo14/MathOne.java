package demo14;

public interface MathOne {
  //	定义一个方法operation
  int operation(int a, int b);
}