package com.qianfeng.hello;

class Hello{
  public static void main(String[] args){
    System.out.println("没有太晚的开始,不如就从今天行动");
  }
}