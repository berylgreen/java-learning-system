package demo12;

import demo11.Penguin;

public class TestPenguin {
  public static void main(String[] args) {
    Penguin p = new Penguin();
    p.fly();
  }
}