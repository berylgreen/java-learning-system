package demo23;

public class TestInterface {

  public static void main(String[] args) {
    String str = "我爱Java";
    System.out.println(str instanceof Object);
    System.out.println(str instanceof String);
  }
}