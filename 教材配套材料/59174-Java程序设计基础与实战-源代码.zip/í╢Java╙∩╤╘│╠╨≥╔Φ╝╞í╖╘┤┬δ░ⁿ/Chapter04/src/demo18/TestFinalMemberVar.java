package demo18;

public class TestFinalMemberVar {

  final int a;

  public static void main(String[] args) {
    final int b;
    b = 10;
  }
}