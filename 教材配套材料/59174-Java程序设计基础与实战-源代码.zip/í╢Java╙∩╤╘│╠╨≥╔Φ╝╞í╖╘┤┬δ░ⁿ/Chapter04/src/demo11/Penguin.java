package demo11;

import demo10.Bird;

public class Penguin extends Bird {
  public void fly() {
    System.out.println("想要飞，却飞呀飞不高！");
  }
}