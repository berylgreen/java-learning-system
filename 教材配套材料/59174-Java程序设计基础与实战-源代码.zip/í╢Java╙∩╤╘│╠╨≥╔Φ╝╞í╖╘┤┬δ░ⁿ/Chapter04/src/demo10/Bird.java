package demo10;

public class Bird {
  public void fly(){
    System.out.println("我要飞的更高！");
  }
}