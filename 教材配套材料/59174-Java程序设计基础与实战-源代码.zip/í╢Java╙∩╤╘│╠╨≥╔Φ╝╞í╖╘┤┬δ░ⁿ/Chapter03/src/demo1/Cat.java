package demo1;

public class Cat {

  public String name;
  public String sex;
  public String color;
  public double age;

  public void sayHello() {        // 定义打招呼的方法
    System.out.println("名字：" + name + " 性别：" + sex + " 毛色" + color + " 年龄" + age);
  }
}