package com.qianfeng.demo25;

public class Employee {

}