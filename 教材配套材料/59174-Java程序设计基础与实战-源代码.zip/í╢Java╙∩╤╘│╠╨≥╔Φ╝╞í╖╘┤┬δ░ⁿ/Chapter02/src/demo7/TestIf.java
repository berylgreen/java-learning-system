package demo7;

public class TestIf {

  public static void main(String[] args) {
    int phone = 988776666;
    if (phone != 123456789) {
      System.out.println("您所拨打的号码是空号！");
    }
  }
}