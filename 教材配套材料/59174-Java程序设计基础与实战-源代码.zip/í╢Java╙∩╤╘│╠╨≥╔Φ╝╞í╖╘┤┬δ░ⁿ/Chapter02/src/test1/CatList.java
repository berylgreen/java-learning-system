package test1;

 public class CatList {

	 public static void main(String[] args) {
		 String name1 = "喵喵";
		 char gender1 = '母';
		 String color1 = "纯色";
		 String locale1 = "二食堂";
		 String name2 = "豆豆";
		 char gender2 = '公';
		 String color2 = "三花";
		 String locale2 = "超市";
		 String name3 = "大壮";
		 char gender3 = '公';
		 String color3 = "三花";
		 String locale3 = "一食堂";
		 System.out.println("昵称" + "\t" + "性别" + "\t" + "花色" + "\t" + "出没地点");
		 System.out.println("--------------------------------------");
		 System.out.println(name1 + "\t" + gender1 + "\t\t" + color1 + "\t" + locale1);
		 System.out.println(name2 + "\t" + gender2 + "\t\t" + color2 + "\t" + locale2);
		 System.out.println(name3 + "\t" + gender3 + "\t\t" + color3 + "\t" + locale3);
		 ;
	 }
 }