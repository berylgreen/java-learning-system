package demo22;

public class TestArrayTraversal {

  public static void main(String[] args) {
    String[] names = {"小喵", "小咪", "翠花", "小面"};
    for (int i = 0; i < names.length; i++) {
      System.out.println(names[i]);
    }
  }
}