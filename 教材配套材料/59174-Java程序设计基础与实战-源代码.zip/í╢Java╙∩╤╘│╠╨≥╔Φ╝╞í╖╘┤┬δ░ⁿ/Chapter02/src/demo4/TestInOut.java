package demo4;

import java.util.Scanner;

public class TestInOut {

  public static void main(String[] args) {
//    Scanner input = new Scanner(System.in);
//    System.out.println("请输入流浪猫的数量：");
//    int num = input.nextInt();
//    System.out.println("流浪猫的数量为" + num);

    int a = 2;
    int b =3;
    System.out.println(a%b*4%b);
  }
}