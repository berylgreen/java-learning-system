package com.qianfeng.syntax;

class HelloWorld {
  /*
  main()方法：程序的入口
  */
  public static void main(String[] args) {
    //向屏幕输出文本“没有太晚的开始，不如就从今天行动”
    System.out.println("没有太晚的开始，不如就从今天行动");
  }
}