package demo6;

public class TestSequence {

  public static void main(String[] args) {
    System.out.println("领养资格申请");
    System.out.println("一对一审核");
    System.out.println("选择猫咪");
    System.out.println("领取猫咪");
    System.out.println("领养反馈");
  }
}