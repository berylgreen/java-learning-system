package demo9;

public class TestAssertion {

	public static void main(String[] args) {
		assert (1 == 0) : "1 和 0 不相等";
	}
}