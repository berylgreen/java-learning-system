package demo13;

public class TestStringDemo02 {

	public static void main(String[] args) {
		String str = "1000phone.com";
		System.out.println(str.charAt(4));
	}
}