package demo14;

public class TestStringDemo03 {

	public static void main(String[] args) {
		String str = " 1000phone.com ";
		System.out.println(str.trim());
	}
}