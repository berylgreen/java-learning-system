package com.qianfeng.demo1;

public class TestDivException {

  public static void main(String[] args) {
    int result = 10 / 0;
    System.out.println(result);
  }
}