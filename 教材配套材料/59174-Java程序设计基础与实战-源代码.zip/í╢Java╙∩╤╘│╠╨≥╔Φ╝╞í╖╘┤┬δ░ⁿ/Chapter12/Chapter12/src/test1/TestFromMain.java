package test1;

import test1.FrmMain;

public class TestFromMain {
	public static void main(String[] args) {
		FrmMain frmMain = new FrmMain();
		frmMain.run();
	}
}